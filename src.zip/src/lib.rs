pub mod engines;
pub mod error;
pub mod ffi;
pub mod session;

use engines::{
    create_engine, Engine, EngineSelector, EngineType, GenerateRequest, HardwareProfile, ModelMeta,
    UserPreference,
};
use error::NezumiError;
use futures::{Stream, StreamExt};
use session::{InMemoryStore, SessionStore};
use std::{pin::Pin, sync::Arc};

pub use engines::{
    GenerateRequest as Request, LoadConfig, ModelMeta as Meta, UserPreference as Preference,
};
pub use error::NezumiError as Error;

pub struct Config {
    pub db_path: Option<String>,
    pub preference: UserPreference,
    pub system_prompt: Option<String>,
}

impl Default for Config {
    fn default() -> Self {
        Self {
            db_path: None,
            preference: UserPreference::Auto,
            system_prompt: None,
        }
    }
}

pub struct NezumiCore {
    engine: Box<dyn Engine>,
    pub session: Arc<dyn SessionStore>,
    preference: UserPreference,
    system_prompt: Option<String>,
}

impl NezumiCore {
    pub async fn init(config: Config) -> Result<Self, NezumiError> {
        let session = Self::build_session(&config).await?;
        let engine = create_engine(EngineType::Llama);
        Ok(Self {
            engine,
            session,
            preference: config.preference,
            system_prompt: config.system_prompt,
        })
    }

    async fn build_session(config: &Config) -> Result<Arc<dyn SessionStore>, NezumiError> {
        #[cfg(feature = "session-sqlite")]
        if let Some(ref path) = config.db_path {
            return Ok(Arc::new(session::sqlite::SqliteStore::new(path).await?));
        }
        Ok(Arc::new(InMemoryStore::new()))
    }

    pub async fn load_model(
        &mut self,
        path: &str,
        config: engines::LoadConfig,
    ) -> Result<(), NezumiError> {
        let meta = ModelMeta::from_path(path);
        let hw = HardwareProfile::detect();
        let engine_type = EngineSelector::select(&meta, &hw, &self.preference);
        let engine = create_engine(engine_type);
        if !engine.supports(&meta) {
            return Err(NezumiError::UnsupportedModel(path.to_string()));
        }
        engine.load(path, config).await?;
        self.engine = engine;
        Ok(())
    }

    /// 生プロンプトで生成（テンプレートなし）
    pub async fn generate(
        &self,
        prompt: &str,
    ) -> Result<impl futures::Stream<Item = String>, NezumiError> {
        self.engine.generate(GenerateRequest::new(prompt)).await
    }

    /// チャット形式で生成（履歴+Gemma3テンプレート）
    fn build_chat_prompt(
        &self,
        history: &[crate::session::Message],
        user_input: &str,
        include_current_input: bool,
    ) -> String {
        let mut prompt = String::new();

        if let Some(ref sys) = self.system_prompt {
            prompt.push_str(&format!("<start_of_turn>system\n{}<end_of_turn>\n", sys));
        }

        for msg in history {
            prompt.push_str(&format!(
                "<start_of_turn>{}\n{}<end_of_turn>\n",
                msg.role, msg.content
            ));
        }

        if include_current_input {
            prompt.push_str(&format!(
                "<start_of_turn>user\n{}<end_of_turn>\n<start_of_turn>model\n",
                user_input
            ));
        }

        prompt
    }

    pub async fn chat(
        &self,
        user_input: &str,
    ) -> Result<impl futures::Stream<Item = String>, NezumiError> {
        let history = self.session.history().await?;
        let prompt = self.build_chat_prompt(&history, user_input, true);
        self.engine.generate(GenerateRequest::new(prompt)).await
    }

    /// チャット生成+履歴保存
    pub async fn chat_and_save(
        &mut self,
        user_input: &str,
        max_tokens: Option<usize>,
        temperature: Option<f32>,
    ) -> Result<Pin<Box<dyn Stream<Item = String> + Send>>, NezumiError> {
        self.session.add("user", user_input).await?;
        let history = self.session.history().await?;
        let mut prompt = self.build_chat_prompt(&history, user_input, false);
        prompt.push_str("<start_of_turn>model\n");
        let req = GenerateRequest {
            prompt,
            max_tokens,
            temperature,
        };
        let mut inner = self.engine.generate(req).await?;
        let session = Arc::clone(&self.session);

        Ok(Box::pin(async_stream::stream! {
            let mut assistant_output = String::new();
            while let Some(token) = inner.next().await {
                assistant_output.push_str(&token);
                yield token;
            }
            let _ = session.add("model", &assistant_output).await;
        }))
    }
}
